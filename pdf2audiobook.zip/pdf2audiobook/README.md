# pdf2audiobook

Convert PDF and TXT files into audiobooks (MP3).

## Features

- Reads `.pdf` and `.txt` files
- Cleans extracted text (de-hyphenation, whitespace normalization)
- Two TTS engines:
  - **gtts** — Google TTS, higher quality, requires internet
  - **pyttsx3** — offline, uses system voices
- Chunks long text automatically

## Install

```bash
pip install -r requirements.txt
```

`gtts` also requires [ffmpeg](https://ffmpeg.org/) on your PATH (used by pydub to stitch chunks).

## Usage

```bash
# Basic (online, Google TTS)
python src/pdf2audiobook.py book.pdf

# Specify output
python src/pdf2audiobook.py notes.txt -o notes.mp3

# Offline engine
python src/pdf2audiobook.py book.pdf -e pyttsx3 -r 160

# Other language (gtts)
python src/pdf2audiobook.py libro.pdf -l es
```

## Options

| Flag | Description |
|------|-------------|
| `-o, --output` | Output MP3 path (default: same name as input) |
| `-e, --engine` | `gtts` (default) or `pyttsx3` |
| `-l, --lang` | Language code, gtts only (default `en`) |
| `-v, --voice` | Voice id, pyttsx3 only |
| `-r, --rate` | Speech rate, pyttsx3 only (default 175) |

## License

MIT
